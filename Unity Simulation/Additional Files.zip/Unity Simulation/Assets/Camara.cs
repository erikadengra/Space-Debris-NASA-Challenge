using UnityEngine;

public class CameraController : MonoBehaviour
{
    public Transform target; // El objeto al que la c�mara se centrar�
    public float distance = 5.0f; // Distancia de la c�mara al objetivo
    public float sensitivity = 3.0f; // Sensibilidad del rat�n
    public float zoomSpeed = 2.0f; // Velocidad del zoom
    public float minDistance = 2.0f; // Distancia m�nima
    public float maxDistance = 10.0f; // Distancia m�xima

    private float rotationX = 0.0f;
    private float rotationY = 0.0f;

    void Start()
    {
        // Hacer que la c�mara empiece mirando al target
        Vector3 angles = transform.eulerAngles;
        rotationX = angles.y;
        rotationY = angles.x;
    }

    void LateUpdate()
    {
        // Solo rotar si el bot�n izquierdo del rat�n est� presionado
        if (Input.GetMouseButton(0))
        {
            // Obtener el movimiento del rat�n
            rotationX += Input.GetAxis("Mouse X") * sensitivity;
            rotationY -= Input.GetAxis("Mouse Y") * sensitivity;
            rotationY = Mathf.Clamp(rotationY, -30f, 80f); // Limitar la rotaci�n vertical
        }

        // Hacer zoom con la rueda del rat�n
        float scroll = Input.GetAxis("Mouse ScrollWheel");
        distance -= scroll * zoomSpeed;
        distance = Mathf.Clamp(distance, minDistance, maxDistance); // Limitar el zoom

        // Calcular la nueva posici�n de la c�mara
        Quaternion rotation = Quaternion.Euler(rotationY, rotationX, 0);
        Vector3 position = target.position - rotation * Vector3.forward * distance;

        // Actualizar la posici�n y rotaci�n de la c�mara
        transform.rotation = rotation;
        transform.position = position;
    }
}