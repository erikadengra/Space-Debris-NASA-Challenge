using UnityEngine;
using System.Collections.Generic;
using System.IO;

public class GeneradorSatelitespink : MonoBehaviour
{
    public Transform cuerpoCentral; // El cuerpo central alrededor del cual orbitan
    public GameObject satelitePrefab; // Prefab del sat�lite que se va a duplicar
    public string rutaArchivoCSV = "Assets/fragments_today_data.csv"; // Ruta del archivo CSV
    public int numeroSatelites = 5; // N�mero de sat�lites a generar

    void Start()
    {
        // Leer los datos del archivo CSV
        List<ParametrosOrbitalespink> parametrosSatelitespink = LeerDatosDesdeCSV(rutaArchivoCSV);
        

        // Verificar si hay suficientes par�metros para los sat�lites
        if (parametrosSatelitespink.Count < numeroSatelites)
        {
            Debug.LogError("No hay suficientes par�metros en el archivo CSV para generar " + numeroSatelites + " sat�lites.");
            return;
        }

        // Crear los sat�lites con los par�metros le�dos
        for (int i = 0; i < numeroSatelites; i++)
        {

            CrearSatelite(parametrosSatelitespink[i]);
        }
    }

    // Funci�n para crear un sat�lite con los par�metros le�dos del CSV
    void CrearSatelite(ParametrosOrbitalespink parametros)
    {
        // Instanciar un nuevo sat�lite basado en el prefab
        GameObject nuevoSatelite = Instantiate(satelitePrefab, Vector3.zero, Quaternion.identity);

        // Obtener el componente Orbita del objeto duplicado
        Orbita orbita = nuevoSatelite.GetComponent<Orbita>();

        // Asignar los par�metros orbitales
        orbita.cuerpoCentral = cuerpoCentral;
        orbita.semiejeMayor = parametros.semiejeMayor;
        orbita.excentricidad = parametros.excentricidad;
        if (parametros.semiejeMayor > 100)
        {
            orbita.inclinacion = parametros.inclinacion;
            orbita.argumentoPeriapsis = 0;
        }
        else
        {
            orbita.inclinacion = parametros.inclinacion - 90;
            orbita.argumentoPeriapsis = parametros.argumentoPeriapsis;
        }
        orbita.longitudNodoAscendente = parametros.longitudNodoAscendente;

        // Asignar el nombre del sat�lite
        nuevoSatelite.name = parametros.nombre;
    }

    // Funci�n para leer el archivo CSV y obtener los par�metros orbitales
    List<ParametrosOrbitalespink> LeerDatosDesdeCSV(string rutaArchivo)
    {
        List<ParametrosOrbitalespink> parametrosList = new List<ParametrosOrbitalespink>();

        // Verificar si el archivo existe
        if (File.Exists(rutaArchivo))
        {
            // Leer todas las l�neas del archivo CSV
            string[] lineas = File.ReadAllLines(rutaArchivo);

            // Comenzar a leer desde la segunda l�nea (ignorando encabezados)
            for (int i = 1; i < lineas.Length; i++)
            {
                string[] valores = lineas[i].Split(',');

                // Asegurarse de que la l�nea tenga el n�mero correcto de columnas
                if (valores.Length == 6)
                {
                    ParametrosOrbitalespink parametros = new ParametrosOrbitalespink
                    {
                        nombre = valores[0], // Nombre del sat�lite
                        semiejeMayor = float.Parse(valores[1]), // Semieje Mayor
                        excentricidad = float.Parse(valores[2]), // Excentricidad
                        inclinacion = float.Parse(valores[3]), // Inclinaci�n
                        longitudNodoAscendente = float.Parse(valores[4]), // Longitud del Nodo Ascendente
                        argumentoPeriapsis = float.Parse(valores[5]) // Argumento del Periapsis
                    };
                    parametrosList.Add(parametros);
                }
                else
                {
                    Debug.LogWarning("L�nea " + (i + 1) + " no tiene el n�mero correcto de columnas.");
                }
            }
        }
        else
        {
            Debug.LogError("El archivo CSV no se encontr� en la ruta: " + rutaArchivo);
        }

        return parametrosList;
    }
}

// Clase para almacenar los par�metros orbitales
public class ParametrosOrbitalespink
{
    public string nombre;
    public float semiejeMayor;
    public float excentricidad;
    public float inclinacion;
    public float longitudNodoAscendente;
    public float argumentoPeriapsis;
}