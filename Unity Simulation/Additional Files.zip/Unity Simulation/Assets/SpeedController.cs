using UnityEngine;
using UnityEngine.UI;

public class GameSpeedController : MonoBehaviour
{
    public Slider speedSlider; // El slider que controlar� la velocidad del juego
    public Text speedText; // Texto para mostrar la velocidad

    void Start()
    {
        // Configura el slider al tiempo de escala inicial
        speedSlider.value = Time.timeScale;

        // A�adir un listener al slider para cambiar la velocidad
        speedSlider.onValueChanged.AddListener(OnSpeedChange);
        UpdateSpeedText();
    }

    // M�todo que se llama cuando cambia el valor del slider
    void OnSpeedChange(float newSpeed)
    {
        Time.timeScale = newSpeed; // Cambiar la velocidad del juego
        UpdateSpeedText();
    }

    // M�todo para actualizar el texto de velocidad
    void UpdateSpeedText()
    {
        speedText.text = "Speed: " + Time.timeScale.ToString("F2"); // Mostrar dos decimales
    }
}