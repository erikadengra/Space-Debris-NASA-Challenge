using UnityEngine;

public class PulsatingEffect : MonoBehaviour
{
    public float pulseSpeed = 1.0f; // Velocidad de pulso
    public float scaleMultiplier = 1.5f; // Tama�o m�ximo al que escalar
    private Vector3 originalScale;

    void Start()
    {
        originalScale = transform.localScale; // Guardar el tama�o original
    }

    void Update()
    {
        float scale = Mathf.PingPong(Time.time * pulseSpeed, scaleMultiplier - 1) + 1;
        transform.localScale = originalScale * scale; // Escalar la esfera
    }
}