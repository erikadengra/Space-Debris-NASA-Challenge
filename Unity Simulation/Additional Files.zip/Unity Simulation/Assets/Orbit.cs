﻿using UnityEngine;

public class Orbita : MonoBehaviour
{
    // Parámetros orbitales
    public Transform cuerpoCentral; // El objeto que será orbitado
    public float semiejeMayor = 10f; // Distancia media desde el cuerpo central
    public float excentricidad = 0.1f; // Forma de la órbita (0 es circular, entre 0 y 1 es elíptica)
    public float inclinacion = 0f; // Inclinación de la órbita en grados
    public float longitudNodoAscendente = 0f; // Ángulo del nodo ascendente en grados
    public float argumentoPeriapsis = 0f; // Ángulo del periapsis en grados
    private float cte = 360f * 360f / 112f / 112f / 112f;
    private float periodoOrbital; // Período orbital en segundos
    private float phase;

    // Tiempo orbital
    private float tiempoOrbital;

    void Start()
    {

        periodoOrbital = Mathf.Sqrt(cte * semiejeMayor * semiejeMayor * semiejeMayor);
        phase = Random.Range(0f, 360f);

    }

    void Update()
    {
        // Avanza el tiempo orbital
        tiempoOrbital += Time.deltaTime;

        // Cálculo del ángulo verdadero
        float anguloVerdadero = (tiempoOrbital / periodoOrbital) * 360f + phase; // Convertimos el tiempo en un ángulo

        // Mantener el ángulo en el rango de 0 a 360
        anguloVerdadero %= 360f;

        // Cálculo de la posición en la órbita elíptica (en 2D)
        float distanciaOrbital = semiejeMayor * (1 - Mathf.Pow(excentricidad, 2)) /
                                 (1 + excentricidad * Mathf.Cos(anguloVerdadero * Mathf.Deg2Rad));

        // Posición en 2D (plano XY)
        Vector3 posicion2D = new Vector3(
            distanciaOrbital * Mathf.Cos(anguloVerdadero * Mathf.Deg2Rad),
            0f,
            distanciaOrbital * Mathf.Sin(anguloVerdadero * Mathf.Deg2Rad)
        );

        // Rotación para inclinar la órbita
        Quaternion inclinacionOrbita = Quaternion.Euler(inclinacion, longitudNodoAscendente, 0f);

        // Aplicar inclinación y argumento del periapsis
        Vector3 posicionFinal = inclinacionOrbita * Quaternion.Euler(0f, 0f, argumentoPeriapsis) * posicion2D;

        // Actualizar la posición del objeto
        transform.position = cuerpoCentral.position + posicionFinal;
    }
}